Sys.setenv("R_TESTS" = "")
library(testthat)
library(RTF2)

test_check("RTF2")
